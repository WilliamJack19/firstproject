<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>Simple House - Food Shop</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
   <link rel="stylesheet" href="assets/css/templatemo-cyborg-gaming.css">    
    <link rel="stylesheet" href="assets/css/mystyle.css">

    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" />    
    <link href="css/templatemo-style.css" rel="stylesheet" />
<!--

TemplateMo 579 Cyborg Gaming

https://templatemo.com/tm-579-cyborg-gaming

-->
  </head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div  class="container">
        <div >
            <div >
                <nav  class="main-nav">
                    
                
                    <!-- ***** Menu Start ***** -->
                     <ul class="nav">
                        <li><a href="home.php">Home</a></li>
                        <li><a href="insert.php">Insert</a></li>
                        <li><a href="view-product.php">Foods & Desserts</a></li>
                        <li><a href="view-order.php" class="active">Order</a></li>
                        <li><a href="view-feedback.php">Feedback</a></li>
                        <li class="live"><a><button onclick="openPopup()" class="love">Logout</button></a></li>
                    </ul>   
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
                <div class="popup1" id="pop">
                  <div class="logout-sec">
                      <div class="logout-head">Log Out</div>
                      <p class="logout_p">Are you sure you want to logout?</p>
                      <div class="logout-btn">
                          <a href="logout.php"><button type="submit" class="btn-blue">Sure</button></a>
                          <button type="submit" class="btn-blue1" id="close_popup" onclick="closePopup()">No</button>
                      </div>
                  </div>
                </div>  
            </div>
        </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="page-content">

          <!-- ***** Banner Start ***** -->
          <div class="row">
            <div class="col-lg-12">
              <div class="main-profile ">
                <div class="row">
                  
                  <div class="col-lg-4 align-self-center">
                    <div class="main-info header-text">
                      <span>Welcome Admin</span>
                      <h4>View Order Form</h4>
                     
                      <table  style="border-color:#efecec;border-style: dotted;margin-left:0px;" width="1000px" align="left" >
					
					<tr><th width="100px" height="50px">ID:</th>					
						<th width="100px" height="50px">Food Name:</th>
						<th width="100px" height="50px">Price:</th>
						<th width="100px" height="50px">Name:</th>
						<th width="100px" height="50px">Phone:</th>
						<th width="100px" height="50px">Address:</th>	
						<th width="100px" height="50px">Order No:</th>						
					 </tr>	
					 <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from orders ");
						while($row=mysql_fetch_array($sel))
							{		
									$id=$row['ord_id'];					
									$prodno=$row['productno'];
									$price=$row['price'];
									$name=$row['name'];
									$phone=$row['phone'];
									$address=$row['address'];
									$ordno=$row['order_no'];
						?>
					 <tr>
						
						<td width="100px" height="50px"><?php echo $id; ?></td>
						<td width="100px" height="50px"><?php echo $prodno; ?></td>
						<td width="100px" height="50px"><?php echo $price; ?></td>
						<td width="100px" height="50px"><?php echo $name; ?></td>
						<td width="100px" height="50px"><?php echo $phone; ?></td>
						<td width="100px" height="50px"><?php echo $address; ?></td>
						<td width="100px" height="50px"><?php echo $ordno; ?></td>
						
						
												
					  </tr>			
					<?php				  
							}	
					?>
					</table>
             
                   <div class="clear"></div>
                  </div>
                  <div style="display:none;" class="nav_up" id="nav_up"></div>
                    </div>
                  </div>
                </div>  
              </div>
			</div>
	      </div>
		  <!-- ***** Banner End ***** -->
		</div>
      </div>
    </div>
  </div>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <p>Copyright © 2023 <a href="#">Simple House</a> Company. All rights reserved. 
          
       
        </div>
      </div>
    </div>
  </footer>
  <?php }  ?>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/tabs.js"></script>
  <script src="assets/js/popup.js"></script>
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/main.js"></script>

  </body>

</html>
