const popup = document.getElementById('pop');
function openPopup(){
    pop.classList.add('popup_active');
}
function closePopup(){
    pop.classList.remove('popup_active');
}