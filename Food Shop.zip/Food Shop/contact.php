<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Simple House - Contact Page</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet" />
    <link href="css/all.min.css" rel="stylesheet" />
	<link href="css/templatemo-style.css" rel="stylesheet" />
</head>
<!--

Simple House

https://templatemo.com/tm-539-simple-house

-->
<body> 

	<div class="container">
	<!-- Top box -->
		<!-- Logo & Site Name -->
		<div class="placeholder">
			<div class="parallax-window" data-parallax="scroll" data-image-src="img/simple-house-01.jpg">
				<div class="tm-header">
					<div class="row tm-header-inner">
						<div class="col-md-6 col-12">
							<img src="img/simple-house-logo.png" alt="Logo" class="tm-site-logo" /> 
							<div class="tm-site-text-box">
								<h1 class="tm-site-title">Simple House</h1>
								<h6 class="tm-site-description">Online Restaurant</h6>	
							</div>
						</div>
						<nav class="col-md-6 col-12 tm-nav">
							<ul class="tm-nav-ul">
								<li class="tm-nav-li"><a href="index.php" class="tm-nav-link">Home</a></li>
								<li class="tm-nav-li"><a href="menu.php" class="tm-nav-link">Menu</a></li>
								<li class="tm-nav-li"><a href="about.php" class="tm-nav-link">About</a></li>
								<li class="tm-nav-li"><a href="register.php" class="tm-nav-link">Register</a></li>
								<li class="tm-nav-li"><a href="contact.php" class="tm-nav-link active">Contact</a></li>
							</ul>
						</nav>	
					</div>
				</div>
			</div>
		</div>

<div class="col-lg-4 align-self-center">
                    <div class="main-info header-text">
                      
                      
                      <?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$phone=$_POST['t3'];
$mesg=$_POST['t4'];
if(mysql_query("insert into content(name,email,phone,mesg) values('$name','$email','$phone','$mesg')"))
{$er="<font color='red' size='+1'> Message sent successfully</font>"; }
}

?>
	
    	<h2>Contact Information</h2>
            <div id="contact_form" class="col_2">
                <h3>Send a message</h3>
                <form method="post" name="contact" action="#">
                    <div class="col_4">
                        <label for="phone">Name:</label><br>
                        <input type="text" id="t1" name="t1" class="required input_field" />
                    </div>
                    <div class="col_4 no_margin_right">
                        <label for="email">Email:</label><br>
                        <input type="email" id="t2" name="t2" class="validate-email required input_field" />
                    </div>
                    <div class="clear h10"></div>
                     <div class="col_4 no_margin_right">
                        <label for="phone">Phone:</label><br>
                        <input type="text" id="t3" name="t3" class="required input_field" />
                    </div>
                    <div class="clear"></div>
                    <label for="text">Message:</label><br>
                    <textarea id="t4" name="t4" rows="0" cols="0" class="required"></textarea><br><br>
                    <input type="submit" name="sub"  id="sub" value="Send" class="submit_button" />
                </form>
				<h2><?php echo $er;?></h2>
            </div> 
                <div>
                  <a href="index.php">Go Back</a>
                </div>
            <div class="col_2 no_margin_right">
                      
                    </div>
                  </div>
                </div>  
              </div>
			</div>
	      </div>
		  <!-- ***** Banner End ***** -->
					<div class="col_2 no_margin_right">
                <div class="col_4">
                    <h3>Location </h3>
                    No(26) PanPanGyi St.,<br />
                    KyeeMyinDaing Township<br />
                    Yangon, Myanmar<br/><br/>
                    
                    Tel: 09798554544<br />
                    Viber: 09798554533<br/>
                    
                   
                    
                </div>
                
			</div>
				</div>
			</div>
            
<!-- How to change your own map point
	1. Go to Google Maps
	2. Click on your location point
	3. Click "Share" and choose "Embed map" tab
	4. Copy only URL and paste it within the src="" field below
-->
			<div class="tm-container-inner-2 tm-map-section">
				<div class="row">
					<div class="col-12">
						<div class="tm-map">
							<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d447.3386167086139!2d96.12327631998346!3d16.81182800368116!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2smm!4v1685892587842!5m2!1sen!2smm" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
						</div>
					</div>
				</div>
			</div>
			
		</main>

		<footer class="tm-footer text-center">
			<p>Copyright &copy; 2023 Simple House 
            
            | Design: <a rel="nofollow" href="https://templatemo.com">TemplateMo</a></p>
		</footer>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/parallax.min.js"></script>
	<script>
		$(document).ready(function(){
			var acc = document.getElementsByClassName("accordion");
			var i;
			
			for (i = 0; i < acc.length; i++) {
			  acc[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var panel = this.nextElementSibling;
			    if (panel.style.maxHeight) {
			      panel.style.maxHeight = null;
			    } else {
			      panel.style.maxHeight = panel.scrollHeight + "px";
			    }
			  });
			}	
		});
	</script>
</body>
</html>