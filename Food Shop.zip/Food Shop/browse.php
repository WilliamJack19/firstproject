<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>Cyborg - Food Online Store</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-cyborg-gaming.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
<!--

TemplateMo 579 Cyborg Gaming

https://templatemo.com/tm-579-cyborg-gaming

-->
  </head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="index.html" class="logo">
                        <img src="assets/images/logo.png" alt="">
                    </a>
                    <!-- ***** Logo End ***** -->
                   
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="browse.php" class="active">About Us</a></li>
                        <li><a href="product.php">Foods & Drinks</a></li>
                        <li><a href="register.php">Register</a></li>
                        
                    </ul>   
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="page-content">

          <!-- ***** Featured Games Start ***** -->
          <div class="row">
            <div class="col-lg-8">
              <div class="featured-games header-text">
                <div class="heading-section">
                  <h4><em>Our</em>Members</h4>
                </div>
                <div class="owl-features owl-carousel">
                  <div class="item">
                    <div class="thumb">
                      <img src="assets/images/sophia.jpg" alt="">
                      <div class="hover-effect">
                        <h6>Sophia</h6>
                      </div>
                    </div>
                    <h4>CEO&Founder</h4>

                  </div>
                  <div class="item">
                    <div class="thumb">
                      <img src="assets/images/bruce.jpg" alt="">
                      <div class="hover-effect">
                        <h6>Bruce</h6>
                      </div>
                    </div>
                    <h4>Co_Founder</h4>

                  </div>
                  <div class="item">
                    <div class="thumb">
                      <img src="assets/images/benjamin.jpg" alt="">
                      <div class="hover-effect">
                        <h6>Benjamin W.</h6>
                      </div>
                    </div>
                    <h4>Restaurant Manager</h4>
                    
                  </div>
                  <div class="item">
                    <div class="thumb">
                      <img src="assets/images/jack.jpg" alt="">
                      <div class="hover-effect">
                        <h6>Muchen Jack</h6>
                      </div>
                    </div>
                    <h4>Main Chef</h4>

                  </div>  
                  <div class="item">
                    <div class="thumb">
                      <img src="assets/images/thanya.jpg" alt="">
                      <div class="hover-effect">
                        <h6>Thanya</h6>
                      </div>
                    </div>
                    <h4>Senior Chef</h4>
                    
                  </div>
                  <div class="item">
                    <div class="thumb">
                      <img src="assets/images/lynda.jpg" alt="">
                      <div class="hover-effect">
                        <h6>Lynda</h6>
                      </div>
                    </div>
                    <h4>New Baker</h4>
                    
                  </div>
                  <div class="item">
                    <div class="thumb">
                      <img src="assets/images/jenny.jpg" alt="">
                      <div class="hover-effect">
                        <h6>Jenny Ko</h6>
                      </div>
                    </div>
                    <h4>Pizza Specialist</h4>
                    
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="top-downloaded">
                <div class="heading-section">
                  <h4><em>Top</em>Order</h4>
                </div>
                <ul>
                  <li>
                    <img src="assets/images/pizza 01.jpg" alt="" class="templatemo-item">
                    <h4>Pizza</h4>
                    <span><i class="fa fa-heart" style="color: yellow;"></i> 49</span>
                    <span><i class="fa fa-dollar" style="color: #ec6090;"></i> 12</span>
                    
                  </li>
                  <li>
                    <img src="assets/images/sandwich.jpg" alt="" class="templatemo-item">
                    <h4>Sandwich</h4>
                    <span><i class="fa fa-heart" style="color: yellow;"></i> 68</span>
                    <span><i class="fa fa-dollar" style="color: #ec6090;"></i> 15</span>
                   
                  </li>
                  <li>
                    <img src="assets/images/malar.jpg" alt="" class="templatemo-item">
                    <h4>Malar Xiang Guo</h4>
                    <span><i class="fa fa-heart" style="color: yellow;"></i> 95</span>
                    <span><i class="fa fa-dollar" style="color: #ec6090;"></i> 14</span>
                    
                  </li>
                </ul>
                <div class="col-lg-12">
                  <div class="main-button">
                      <div class="text-button">
                           <a href="product.php">Order</a>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- ***** Featured Games End ***** -->

         
          <!-- ***** Live Stream Start ***** -->
          <div class="live-stream">
            <div class="col-lg-12">
              <div class="heading-section">
                <h4><em>Feedback &</em>Review</h4>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-sm-6">
                <div class="item">
                  <div class="thumb">
                    <img src="assets/images/mark.jpg" alt="">
                    <div class="hover-effect">
                     
                    </div>
                  </div>
                  <div class="down-content">
                    <div class="avatar">
                      <img src="assets/images/mark.jpg" alt="" style="max-width: 46px; border-radius: 50%; float: left;">
                    </div>
                    <span><i class="fa fa-check"></i>Mark Zukerberg</span>
                    <h4>Just Talking With Fans</h4>
                  </div> 
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div class="item">
                  <div class="thumb">
                    <img src="assets/images/bill.jpg" alt="">
                    <div class="hover-effect">
                     
                    </div>
                  </div>
                  <div class="down-content">
                    <div class="avatar">
                      <img src="assets/images/bill.jpg" alt="" style="max-width: 46px; border-radius: 50%; float: left;">
                    </div>
                    <span><i class="fa fa-check"></i>Bill Gates</span>
                    <h4>CS-GO 36 Hours Live Stream</h4>
                  </div> 
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div class="item">
                  <div class="thumb">
                    <img src="assets/images/steve.jpg" alt="">
                    <div class="hover-effect">
                      <div class="content">
                        
                      </div>
                    </div>
                  </div>
                  <div class="down-content">
                    <div class="avatar">
                      <img src="assets/images/steve.jpg" alt="" style="max-width: 46px; border-radius: 50%; float: left;">
                    </div>
                    <span><i class="fa fa-check"></i>Steve Jobs</span>
                    <h4>Maybe Nathej Allnight Chillin'</h4>
                  </div> 
                </div>
              </div>
              <div class="col-lg-3 col-sm-6">
                <div class="item">
                  <div class="thumb">
                    <img src="assets/images/michael.jpg" alt="">
                    <div class="hover-effect">
                      <div class="content">
                       
                        
                      </div>
                    </div>
                  </div>
                  <div class="down-content">
                    <div class="avatar">
                      <img src="assets/images/michael.jpg" alt="" style="max-width: 46px; border-radius: 50%; float: left;">
                    </div>
                    <span><i class="fa fa-check"></i>Michael Jordan</span>
                    <h4>Live Streaming Till Morning</h4>
                  </div> 
                </div>
              </div>
              <div class="col-lg-12">
                <div class="main-button">
                  <a href="contact.php">Contact Us</a>
                </div>
              </div>
            </div>
          </div>
          <!-- ***** Live Stream End ***** -->

        </div>
      </div>
    </div>
  </div>
  
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <p>Copyright © 2036 <a href="#">Cyborg Food Delivery</a> Company. All rights reserved. 
          
          <br>Design By: <a href="https://templatemo.com" target="_blank" title="free CSS templates">TemplateMo</a></p>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/tabs.js"></script>
  <script src="assets/js/popup.js"></script>
  <script src="assets/js/custom.js"></script>


  </body>

</html>
