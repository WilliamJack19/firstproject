<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Simple House</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" />    
	<link href="css/templatemo-style.css" rel="stylesheet" />
</head>
<!--

Simple House

https://templatemo.com/tm-539-simple-house

-->
<body> 

	<div class="container">
	<!-- Top box -->
		<!-- Logo & Site Name -->
		<div class="placeholder">
			<div class="parallax-window" data-parallax="scroll" data-image-src="img/simple-house-01.jpg">
				<div class="tm-header">
					<div class="row tm-header-inner">
						<div class="col-md-6 col-12">
							<img src="img/simple-house-logo.png" alt="Logo" class="tm-site-logo" /> 
							<div class="tm-site-text-box">
								<h1 class="tm-site-title">Simple House</h1>
								<h6 class="tm-site-description">Online Restaurant</h6>	
							</div>
						</div>
						<nav class="col-md-6 col-12 tm-nav">
							<ul class="tm-nav-ul">
								<li class="tm-nav-li"><a href="index.php" class="tm-nav-link active">Home</a></li>
								<li class="tm-nav-li"><a href="menu.php" class="tm-nav-link">Menu</a></li>
								<li class="tm-nav-li"><a href="about.php" class="tm-nav-link">About</a></li>
								<li class="tm-nav-li"><a href="register.php" class="tm-nav-link">Register</a></li>
								<li class="tm-nav-li"><a href="contact.php" class="tm-nav-link">Contact</a></li>
							</ul>
						</nav>	
					</div>
				</div>
			</div>
		</div>

		<main>
			<header class="row tm-welcome-section">
				<h2 class="col-12 text-center tm-section-title">Welcome to Simple House</h2>
				<p class="col-12 text-center">Hi! How Are You? Please let us introduce our 
				Online Food Order & Delivery Service.You can order food from your favourite food and dessert from our shop.It is very easy to order and we will deliver to your doorstep.We accept orders from 9:30am to 8:30pm.</p><br>
				<p>------------------------------------------------------------------------------------------------------------------------------------------------------------------------</p><br><br><br>
				<p><b>This page is only show our menu and catagories.And you can also know our menu's ingridrients.If you order,please go to the "Menu" page.Thank you and have a nice day ^-^</b></p> 
			</header>
			
			<div class="tm-paging-links">
				<nav>
					<ul>
						<li class="tm-paging-item"><a href="#" class="tm-paging-link active">Main</a></li>
						<li class="tm-paging-item"><a href="#" class="tm-paging-link">Appetizer</a></li>
						<li class="tm-paging-item"><a href="#" class="tm-paging-link">Desserts</a></li>
					</ul>
				</nav>
			</div>

			<!-- Gallery -->
			<div class="row tm-gallery">
				<!-- gallery page 1 -->
				<div id="tm-gallery-page-main" class="tm-gallery-page">
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Ramen.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Ramen</h4>
								<p class="tm-gallery-description">Ramen, Soup, Meat, Egg, Vegetables, Mushroom, Seaweed</p>
								<p class="tm-gallery-price">6500 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Pizza.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Pizza</h4>
								<p class="tm-gallery-description">Sausage, Vegetables, Tomatos, Bacon, Sauce</p>
								<p class="tm-gallery-price">14000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Rice.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Fried Rice</h4>
								<p class="tm-gallery-description">You can choose 3 Types.Burmese, Malaysia, Chinese Fried Rice.</p>
								<p class="tm-gallery-price">3000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Set.jpg" alt="Image" class="img-fluid tm-gallery-img" /><br><br><br><br><br>
							<figcaption>
								<h4 class="tm-gallery-title">Rice Set</h4>
								<p class="tm-gallery-description">Rice, Meat(or)Fish, Vegetables, Sauce, Small Salad</p>
								<p class="tm-gallery-price">3000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Chicken.jpeg" alt="Image" class="img-fluid tm-gallery-img" /><br><br>
							<figcaption>
								<h4 class="tm-gallery-title">Fried Chicken</h4>
								<p class="tm-gallery-description">You can choose Wings(or)Drumstick(or)Meat</p>
								<p class="tm-gallery-price">4500 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Katsu.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Katsu Curry</h4>
								<p class="tm-gallery-description">Rice, Meat, Sauce, Vegetables, Soy, Potatos</p>
								<p class="tm-gallery-price">6000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/16.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Kyay Oh</h4>
								<p class="tm-gallery-description">Noodle, Soup, Sauce, Egg, Meat, Vegetables, Meat Ball</p>
								<p class="tm-gallery-price">5000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Strew.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Beef Strew</h4>
								<p class="tm-gallery-description">Beef, Soup, Vegetables, Carrot, Potatos</p>
								<p class="tm-gallery-price">120000 MMK</p>
							</figcaption>
						</figure>
					</article>
				</div> <!-- gallery page 1 -->
				
				<!-- gallery page 2 -->
				<div id="tm-gallery-page-appetizer" class="tm-gallery-page hidden">
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Ball.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Chicken Meat Ball</h4>
								<p class="tm-gallery-description">Chicken, Sauce, Vegetables</p><br>
								<p class="tm-gallery-price">4000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Salad.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Salad</h4>
								<p class="tm-gallery-description">Vegetables, Fruits, Sauce, Meat, Mayonnies, Soy</p>
								<p class="tm-gallery-price">3500 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Dump.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Dumpling</h4>
								<p class="tm-gallery-description">You can choose Pizza Dumplings (or)
								Charcoal Dumplings</p>
								<p class="tm-gallery-price">3000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Ham.jpg" alt="Image" class="img-fluid tm-gallery-img" /><br><br><br>
							<figcaption>
								<h4 class="tm-gallery-title">Hamburger</h4>
								<p class="tm-gallery-description">Bread, Meat, Vegetables, Cucumber, Tomatos, Lettuces,
								</p>
								<p class="tm-gallery-price">5000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Hot.jpg" alt="Image" class="img-fluid tm-gallery-img" /><br><br>
							<figcaption>
								<h4 class="tm-gallery-title">Hot Dog</h4>
								<p class="tm-gallery-description">Bread, Meat, Vegetables, Sauce, Sausages, Chips</p>
								<p class="tm-gallery-price">4500 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Tako.jpg" alt="Image" class="img-fluid tm-gallery-img" /><br><br>
							<figcaption>
								<h4 class="tm-gallery-title">Takoyaki</h4>
								<p class="tm-gallery-description">Meat, Sauce, Soy, Mayonnies and
								other ingridrients</p>
								<p class="tm-gallery-price">4000 MMK</p>
							</figcaption>
						</figure>
					</article>

					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Sushi.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Sushi</h4>
								<p class="tm-gallery-description">Meat, Sauce, Soy, Mayonnies, Rice, Sasame</p>
								<p class="tm-gallery-price">4000 MMK</p>
							</figcaption>
						</figure>
					</article>

					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Corn.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Corn Dog</h4>
								<p class="tm-gallery-description">Meat, Sauce, Soy, Mayonnies, Sausage, Soy</p>
								<p class="tm-gallery-price">3000 MMK</p>
							</figcaption>
						</figure>
					</article>
				</div> <!-- gallery page 2 -->
				
				<!-- gallery page 3 -->
				<div id="tm-gallery-page-desserts" class="tm-gallery-page hidden">
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/bl.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Ocean In Top Sea</h4>
								<p class="tm-gallery-description">You can choose Blueberry (or) Raspberry. You can also Choose Beer Base(or) Rum Base (or) Soda Only.</p>
								<p class="tm-gallery-price">8000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Cola.jpeg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Drink</h4>
								<p class="tm-gallery-description">You can choose Cola/ Orange/ Spirit/ Cream Soda/ Lime</p>
								<br><br>
								<p class="tm-gallery-price">1000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Bread.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Bread Toast</h4>
								<p class="tm-gallery-description">Bread, Jam, Butter, Banana, Grape</p><br><br><br>
								<p class="tm-gallery-price">3000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/La.jpeg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Ice Salad</h4>
								<p class="tm-gallery-description">Ice Cream, Jelly, Fruit, Milk </p><br><br><br>
								<p class="tm-gallery-price">4000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/IC.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Ice Cream</h4>
								<p class="tm-gallery-description">You can choose 10 Flavours. Chocolate,Milk,Strawberry,Fruit,
								Rainbow,Taro,Mango,Durian,
								Green Tea,Charcoal.
								You can also choose many Toppings.</p><br>
								<p class="tm-gallery-price">3000 MMK</p>
							</figcaption>
						</figure>
					</article>
					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Ice.jpg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Ice Coffee</h4>
								<p class="tm-gallery-description">You can choose
								Americano,Latte,Cappochino,
								Mocha,Fruppe,Espresso,Macchiato.
								You can also choose Hot (or) Cold.</p><br>
								<p class="tm-gallery-price">4000 MMK</p>
							</figcaption>
						</figure>
					</article>

					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Fa.jpeg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Faluda</h4>
								<p class="tm-gallery-description">Ice Cream, Milk, Pudding, Jelly and other manay ingrediants</p>
								<p class="tm-gallery-price">5000 MMK</p>
							</figcaption>
						</figure>
					</article>

					<article class="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
						<figure>
							<img src="image/Bing.jpeg" alt="Image" class="img-fluid tm-gallery-img" />
							<figcaption>
								<h4 class="tm-gallery-title">Bingsu</h4>
								<p class="tm-gallery-description">You can choose Mango, Strawberry, Chocolate, Papaya, Grape.And you can also choose Wafu and Fruits.</p>
								<p class="tm-gallery-price">6000 MMK</p>
							</figcaption>
						</figure>
					</article>

				</div> <!-- gallery page 3 -->
			</div>
			
		</main>

		<footer class="tm-footer text-center">
			<p>Copyright &copy; 2023 Simple House 
            
            | Design: <a rel="nofollow" href="https://templatemo.com">TemplateMo</a></p>
		</footer>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/parallax.min.js"></script>
	<script>
		$(document).ready(function(){
			// Handle click on paging links
			$('.tm-paging-link').click(function(e){
				e.preventDefault();
				
				var page = $(this).text().toLowerCase();
				$('.tm-gallery-page').addClass('hidden');
				$('#tm-gallery-page-' + page).removeClass('hidden');
				$('.tm-paging-link').removeClass('active');
				$(this).addClass("active");
			});
		});
	</script>
</body>
</html>