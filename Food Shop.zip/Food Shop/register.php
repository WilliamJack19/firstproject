<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Simple House</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" />    
  <link href="css/templatemo-style.css" rel="stylesheet" />
  <!-- <link href="tooplate_style.css" rel="stylesheet" type="text/css" /> -->
  
     
</head>
<!--

Simple House

https://templatemo.com/tm-539-simple-house

-->
<body> 

  <div class="container">
  <!-- Top box -->
    <!-- Logo & Site Name -->
    <div class="placeholder">
      <div class="parallax-window" data-parallax="scroll" data-image-src="img/simple-house-01.jpg">
        <div class="tm-header">
          <div class="row tm-header-inner">
            <div class="col-md-6 col-12">
              <img src="img/simple-house-logo.png" alt="Logo" class="tm-site-logo" /> 
              <div class="tm-site-text-box">
                <h1 class="tm-site-title">Simple House</h1>
                <h6 class="tm-site-description">Online Restaurant</h6>  
              </div>
            </div>
            <nav class="col-md-6 col-12 tm-nav">
              <ul class="tm-nav-ul">
                <li class="tm-nav-li"><a href="index.php" class="tm-nav-link">Home</a></li>
                <li class="tm-nav-li"><a href="menu.php" class="tm-nav-link">Menu</a></li>
                <li class="tm-nav-li"><a href="about.php" class="tm-nav-link">About</a></li>
                <li class="tm-nav-li"><a href="register.php" class="tm-nav-link active">Register</a></li>
                <li class="tm-nav-li"><a href="contact.php" class="tm-nav-link">Contact</a></li>
              </ul>
            </nav>  
          </div>
        </div>
      </div>
    </div>

<div id="tooplate_wrapper">
  
     <h3 align="center" >Register form</h3>
           <div id="tooplate_main">
      <div id="tooplate_content" class="left">
          <div id="comment_form">
            <?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$password=$_POST['t3'];
$phone=$_POST['t4'];
$city=$_POST['t5'];
$town=$_POST['t6'];
if(mysql_query("insert into register(name,email,password,phone,city,township) values('$name','$email','$password','$phone','$city','$town')"))
{
//echo "<script>location.href='reg_success.php?email=$email'</script>"; 
header("location:reg_success.php?name=$name & email=$email");}
else {$error= "user already exists";}}

?>
            <form  method="post">
                <label>Name </label>
                <input type="text" name="t1" id="t1" class="input_field" />
                <label>Email</label>
                <input type="email" name="t2" id="t2" class="input_field" />
                <label>Password</label>
                <input type="password" name="t3" id="t3" class="input_field" />
                <label>Phone </label>
                <input type="text" name="t4" id="t4" class="input_field" />
                <label>City </label>
                <input type="text" name="t5" id="t5" class="input_field" />
                <label>Country </label>
                <input type="text" name="t6" id="t6" class="input_field" />
                <input type="submit" name="sub" id="sub" value="Register" class="submit_button" />
                <input type="reset" name="Cancel" value="Cancel" class="submit_button" />
                <label><?php echo "<font color='red'>$error</font>";?></label>
            </form>
            
        
        </div>  
            
            
            
            
            
            
        </div> <!-- END of content -->
                
    
            
           
      </div>
        
        <div class="clear"></div>
    
    </div> <!-- END of tooplate_main -->
    <div style="display:none;" class="nav_up" id="nav_up"></div>
</div> <!-- END of tooplate_wrapper -->

    <footer class="tm-footer text-center">
      <p>Copyright &copy; 2023 Simple House 
            
            | Design: <a rel="nofollow" href="https://templatemo.com">TemplateMo</a></p>
    </footer>
  </div>
  <script src="js/jquery.min.js"></script>
  <script src="js/parallax.min.js"></script>
  <script>
    $(document).ready(function(){
      // Handle click on paging links
      $('.tm-paging-link').click(function(e){
        e.preventDefault();
        
        var page = $(this).text().toLowerCase();
        $('.tm-gallery-page').addClass('hidden');
        $('#tm-gallery-page-' + page).removeClass('hidden');
        $('.tm-paging-link').removeClass('active');
        $(this).addClass("active");
      });
    });
  </script>
</body>
</html>