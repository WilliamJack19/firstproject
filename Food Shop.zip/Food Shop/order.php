<?php
error_reporting(1);
session_start();
$i=$_REQUEST['img'];
$_SESSION['sid']=$_POST['id'];
include("connection.php");
$i=$_REQUEST['img'];
if($_POST['ord'])
{ 
$prodno=$_POST['prodno'];
$price=$_POST['price'];
$name=$_POST['nam'];
$phone=$_POST['pho'];
$add=$_POST['add'];
$ordno=ord.rand(100,500);
if(mysql_query("insert into orders(productno,price,name,phone,address,order_no) values('$prodno','$price','$name','$phone','$add','$ordno')"))
{
//echo "<script>location.href='ordersent.php?prod'</script>";
header("location:ordersent.php?order_no=$ordno");  }
else {$error= "user already exists";}}

?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<title>Simple House</title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" />    
  <link href="css/templatemo-style.css" rel="stylesheet" />
  <!-- <link href="tooplate_style.css" rel="stylesheet" type="text/css" /> -->
  
	 
</head>
<!--

Simple House

https://templatemo.com/tm-539-simple-house

-->
<body> 

  <div class="container">
  <!-- Top box -->
	<!-- Logo & Site Name -->
	<div class="placeholder">
	  <div class="parallax-window" data-parallax="scroll" data-image-src="img/simple-house-01.jpg">
		<div class="tm-header">
		  <div class="row tm-header-inner">
			<div class="col-md-6 col-12">
			  <img src="img/simple-house-logo.png" alt="Logo" class="tm-site-logo" /> 
			  <div class="tm-site-text-box">
				<h1 class="tm-site-title">Simple House</h1>
				<h6 class="tm-site-description">Online Restaurant</h6>  
			  </div>
			</div>
			<nav class="col-md-6 col-12 tm-nav">
			  <ul class="tm-nav-ul">
				<li class="tm-nav-li"><a href="index.php" class="tm-nav-link">Home</a></li>
				<li class="tm-nav-li"><a href="menu.php" class="tm-nav-link">Menu</a></li>
				<li class="tm-nav-li"><a href="about.php" class="tm-nav-link">About</a></li>
				<li class="tm-nav-li"><a href="register.php" class="tm-nav-link active">Register</a></li>
				<li class="tm-nav-li"><a href="contact.php" class="tm-nav-link">Contact</a></li>
			  </ul>
			</nav>  
		  </div>
		</div>
	  </div>
	</div>

	<div id="tooplate_main">
  
	  <div id="tooplate_content" class="left">
		  <div id="comment_form">
			<h3>Order form</h3>
		<?php
	  include("connection.php");
	  $sel=mysql_query("select * from item  where img='$i' ");
	  $mat=mysql_fetch_array($sel);
	  
	  
	  ?>
			<form  method="post">
		
				<label>Product No </label>
				<input type="text" name="prodno" id="prodno" value="<?php echo $mat['prod_no'];?>" class="input_field" />
				<label>price  </label>
				<input type="text" name="price" id="price" value="<?php echo $mat['price'];?>" class="input_field" />
		 <label>Name </label>
				<input type="text" name="nam" id="nam" class="input_field" />
		 <label>Phone </label>
				<input type="text" name="pho" id="php" class="input_field" />
		 <label>Address</label>
				<textarea id="add" name="add" rows="0" cols="0" class="required"></textarea>
		 
				<input type="submit" name="ord" id="ord" value="sent order" class="submit_button" />
		 <input type="submit" name="Cancel" value="Cancel" class="submit_button" />
		
			</form>
			
		
		</div>  
			
			
			
			
			
			
		</div> <!-- END of content -->
				
	
			
		   
	  </div>
		
		<div class="clear"></div>
	
	</div> <!-- END of tooplate_main -->
	<div style="display:none;" class="nav_up" id="nav_up"></div>
</div> <!-- END of tooplate_wrapper -->


		  

	<footer class="tm-footer text-center">
	  <p>Copyright &copy; 2023 Simple House 
			
			| Design: <a rel="nofollow" href="https://templatemo.com">TemplateMo</a></p>
	</footer>
  </div>
  <script src="js/jquery.min.js"></script>
  <script src="js/parallax.min.js"></script>
  <script>
	$(document).ready(function(){
	  // Handle click on paging links
	  $('.tm-paging-link').click(function(e){
		e.preventDefault();
		
		var page = $(this).text().toLowerCase();
		$('.tm-gallery-page').addClass('hidden');
		$('#tm-gallery-page-' + page).removeClass('hidden');
		$('.tm-paging-link').removeClass('active');
		$(this).addClass("active");
	  });
	});
  </script>
</body>
</html>